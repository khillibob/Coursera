best <- function(state, outcome) {
        ## Read outcome data
        #state='TX'
        tab <- read.csv("outcome-of-care-measures.csv", colClasses = "character")
        #tab<-tab[complete.cases(tab[,]),];
        
        ## Check that state and outcome are valid
        checkState = tab[,7];
        checkState = checkState[state==checkState]
        if(length(checkState)<1){
                stop("invalid state");
        }
        
       # outcome <-"heart attack"
        out<-c("heart attack", "heart failure",  "pneumonia");
        if(length(out[outcome==out])<1){
                stop("invalid outcome");
        }
        ## Return hospital name in that state with lowest 30-day death
        ## rate
        max_name<-""
        tab <- tab[state==tab[,7],];
        if(outcome==out[2]){
                
                tab_num <-tab;
                tab_num[,17]<-as.numeric(unlist(tab[17]))
                tab1<-tab_num[complete.cases(tab_num[,17]),];
                #print(a)
                #print(length(tab))
               # names <- tab1[a==tab[,12],]
                
                #names<-names[names$State==state,]
                minval<-min(tab1[,17]);
                min_tab<-tab1[(tab1[,17]==minval),]
                names<-min_tab$Hospital.Name
                #print(names)
                max_name<-min(names)
                max_name<-max_name[1]
                
        }
        else if(outcome==out[1]){
                print('1')
                tab_num <-tab;
                tab_num[,11]<-as.numeric(unlist(tab[11]))
                tab1<-tab_num[complete.cases(tab_num[11]),];
                #print(a)
                #print(length(tab))
                # names <- tab1[a==tab[,12],]
                print('1_1')
                #names<-names[names$State==state,]
                minval<-min(tab1[,11]);
                min_tab<-tab1[(tab1[,11]==minval),]
                names<-min_tab$Hospital.Name
                #print(names)
                print('1_2')
                
                max_name<-min(names)
                max_name<-max_name[1]
                
        }
        else if(outcome==out[3]){
                
                tab_num <-tab;
                tab_num[,23]<-as.numeric(unlist(tab[23]))
                tab1<-tab_num[complete.cases(tab_num[,23]),];
                #print(a)
                #print(length(tab))
                # names <- tab1[a==tab[,12],]
                
                #names<-names[names$State==state,]
                minval<-min(tab1[,23]);
                min_tab<-tab1[(tab1[,23]==minval),]
                names<-min_tab$Hospital.Name
                #print(names)
                max_name<-min(names)
                max_name<-max_name[1]
                
        }
        max_name
}

rankhospital <- function(state, outcome, num = "best") {
        ## Read outcome data
        ## Check that state and outcome are valid
        ## Return hospital name in that state with the given rank
        ## 30-day death rate
        
        tab <- read.csv("outcome-of-care-measures.csv", colClasses = "character")
        #tab<-tab[complete.cases(tab[,]),];
        
        ## Check that state and outcome are valid
        checkState = tab[,7];
        checkState = checkState[state==checkState]
        if(length(checkState)<1){
                stop("invalid state");
        }
        
        # outcome <-"heart attack"
        out<-c("heart attack", "heart failure",  "pneumonia");
        if(length(out[outcome==out])<1){
                stop("invalid outcome");
        }
        ## Return hospital name in that state with lowest 30-day death
        ## rate
        max_name<-""
        tab <- tab[state==tab[,7],];
        if(outcome==out[2]){
                
                tab_num <-tab;
                tab_num[,17]<-as.numeric(unlist(tab[17]))
                tab1<-tab_num[complete.cases(tab_num[,17]),];
                #print(a)
                #print(length(tab))
                # names <- tab1[a==tab[,12],]
                
                #names<-names[names$State==state,]
                minval<-min(tab1[,17]);
                min_tab<-tab1[(tab1[,17]==minval),]
                names<-min_tab$Hospital.Name
                #print(names)
                max_name<-min(names)
                max_name<-max_name[1]
                
        }
        else if(outcome==out[1]){
                print('1')
                tab_num <-tab;
                tab_num[,11]<-as.numeric(unlist(tab[11]))
                tab1<-tab_num[complete.cases(tab_num[11]),];
                #print(a)
                #print(length(tab))
                # names <- tab1[a==tab[,12],]
                #names<-names[names$State==state,]
                minval<-min(tab1[,11]);
                min_tab<-tab1[(tab1[,11]==minval),]
                names<-min_tab$Hospital.Name
                #print(names)
                
                max_name<-min(names)
                max_name<-max_name[1]
                
        }
        else if(outcome==out[3]){
                
                tab_num <-tab;
                tab_num[,23]<-as.numeric(unlist(tab[23]))
                tab1<-tab_num[complete.cases(tab_num[,23]),];
                #print(a)
                #print(length(tab))
                # names <- tab1[a==tab[,12],]
                
                #names<-names[names$State==state,]
                minval<-min(tab1[,23]);
                min_tab<-tab1[(tab1[,23]==minval),]
                names<-min_tab$Hospital.Name
                #print(names)
                max_name<-min(names)
                max_name<-max_name[1]
                
        }
        max_name
        
}

dispHist <- function(){
        outcome <- read.csv("outcome-of-care-measures.csv", colClasses = "character");
        outcome[, 11] <- as.numeric(outcome[, 11]);
        hist(outcome[, 11]);
        
}